//
//  ViewController.swift
//  AdaptiveLayoutProject
//
//  Created by Allen Boynton on 5/6/16.
//  Copyright © 2016 Full Sail. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    // MARK: - Properties
    
    // Local variables - all values change thoughout the game
    
    // Image array
    var cardImages: [String] = []
    
    // Counts number of cards remaining
    var cardCounter = 0
    
    // NSTimers for game counter and delay in revealed images
    var timer  = NSTimer(), timer2 = NSTimer(), timer3 = NSTimer()
    
    // Time values instantiated
    var minutes: Int = 0
    var seconds: Double = 0
    var time: String = ""
    
    // Image removed from array
    var selectedImages: [UIImage?] = []
    var image: UIImage!
    
    // Display arrays
    var displayLabelsArray: [UILabel?] = []
    var displayViewsArray: [UIView?] = []
    
    // Initial play game screen
    @IBOutlet weak var playScreenView: UIView!
    @IBOutlet weak var gameNameTitle: UIImageView!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var inputField: UITextField!
    
    // Game screen displays
    @IBOutlet weak var gameView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var playerDisplay2: UILabel!
    @IBOutlet weak var dateDisplay2: UILabel!
    @IBOutlet weak var timerDisplay: UILabel!
    @IBOutlet weak var movesDisplay: UILabel!
    @IBOutlet weak var playerDisplay: UILabel!
    @IBOutlet weak var dateDisplay: UILabel!
    @IBOutlet weak var leftSidebar: UIView!
    @IBOutlet weak var rightSidebar: UIView!
    @IBOutlet weak var leftLowerSidebar: UIView!
    @IBOutlet weak var rightLowerSidebar: UIView!
    
    // Image view outlet collection for memory cards
    @IBOutlet var imageButtonsArray: [UIButton]!
    
    // Winner final screen view
    @IBOutlet weak var finalBackgroundView: UIView!
    @IBOutlet weak var finalTime: UILabel!
    @IBOutlet weak var resultsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Check to see how many buttons are on the screen to determine iPhone or iPad
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone {
            
            // iPhone array for 20 buttons
            cardImages = [
                "misc space rocket.png", "tools rope.png", "tools saw.png",
                "tools screwdriver.png", "tools shovel.png", "tools swiss knife.png",
                "tools torch.png", "tools wrench.png", "weapons gaunlets.png",
                "weapons katana.png", "misc space rocket.png", "tools rope.png", "tools saw.png",
                "tools screwdriver.png", "tools shovel.png", "tools swiss knife.png",
                "tools torch.png", "tools wrench.png", "weapons gaunlets.png",
                "weapons katana.png"
            ]
            randomImageLoop()
            
        } else if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            
            // iPad array for 30 buttons
            cardImages = [
                "misc space rocket.png", "tools rope.png", "tools saw.png",
                "tools screwdriver.png", "tools shovel.png", "tools swiss knife.png",
                "tools torch.png", "tools wrench.png", "weapons gaunlets.png",
                "weapons katana.png", "magic wizard hat.png", "weapons medieval helmet.png",
                "weapons medieval sword.png", "weapons sledgehammer.png", "weapons wood shield.png",
                "misc space rocket.png", "tools rope.png", "tools saw.png",
                "tools screwdriver.png", "tools shovel.png", "tools swiss knife.png",
                "tools torch.png", "tools wrench.png", "weapons gaunlets.png",
                "weapons katana.png", "magic wizard hat.png", "weapons medieval helmet.png",
                "weapons medieval sword.png", "weapons sledgehammer.png", "weapons wood shield.png"
            ]
            randomImageLoop()
        }
        
        // Verify value of array indeces
        print(imageButtonsArray.indices)
        
        
        // Display attributes
        
        // Image buttons
        for imageButton in imageButtonsArray {
            imageButton.layer.cornerRadius = 4
            imageButton.layer.borderWidth = 2
            imageButton.layer.borderColor = UIColor.blackColor().CGColor
        }
        
        // Label array
        displayLabelsArray = [playerDisplay, playerDisplay2, dateDisplay, dateDisplay2, movesDisplay, timerDisplay]
        
        for label in displayLabelsArray {
            label!.layer.borderWidth = 2
            label!.layer.borderColor = UIColor.blackColor().CGColor
        }
        
        // View array
        displayViewsArray = [leftSidebar, leftLowerSidebar, rightSidebar, rightLowerSidebar]
        
        for views in displayViewsArray {
            views!.layer.borderWidth = 4
            views!.layer.borderColor = UIColor.blackColor().CGColor
        }
    }
    
    // for in loop to populate array images by removing a random one at a time while array depletes to ensure pairs
    func randomImageLoop() {
        for index in imageButtonsArray {
            if cardImages.count > 0 {
                let random = arc4random_uniform(UInt32(cardImages.count))
                image = UIImage(named: cardImages.removeAtIndex(Int(random)))
                // Set Normal image
                index.setImage(UIImage(named: "question.png"), forState: .Normal)
                // Set Selected image
                index.setImage(image, forState: .Selected)
                // Allows image to change to selected and stay, not toggle or do nothing
                index.addTarget(self, action: #selector(ViewController.buttonTapped(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            }
        }
    }
    
    // Allows buttons to be selected and change image
    func buttonTapped(sender: UIButton) {
        sender.selected = !sender.selected
    }
    
    // Switch statement to match buttons and help perform actions
    
    
    // Tap function to verify buttons have been tapped
    @IBAction func buttonsTapped(sender: UIButton) {
        
        let tagger = sender.tag
        
        sender.selected = true
        
        if let tappedImage = sender.imageView {
            selectedImages += [tappedImage.image]
            
            if selectedImages.count == 2 {
                
                if selectedImages[tagger] == selectedImages[tagger] {
                    removeCards()
                    print("It's a match")
                } else {
                    hideCards()
                    print("No match")
                }
            }
        }
    }
    
    // Function used to hide images when the user does not get a match
    func hideCards () {
        
        // Removes the selected boxes from the selected boxes array, allowing the user to start selecting more boxes
        selectedImages.removeAll(keepCapacity: false)
        
        // Renables user interaction.
        view.userInteractionEnabled = true
        
        print("Point hit at hideCards")
    }
    
    // Function used to remove images when the user gets a match.
    func removeCards () {
        for card in imageButtonsArray {
            card.hidden = true
            print("Point hit at removeCards")
        }
        
        // This iterates the card counter backwards by 2, while removing the 2 matched cards from the total
        cardCounter -= 1
        cardCounter -= 1
        
        movesDisplay!.text = String(cardCounter)
        print(cardCounter)
        
        selectedImages.removeAll(keepCapacity: true)
        
        // This checks if all cards have been matched and moves to the winner screen
        if cardCounter == 0 {

            // This stops the game timer
            timer.invalidate()
            
            // Opens winners screen
            finalBackgroundView.hidden = false
            
            // Hides title and game view screen
            headerView.hidden  = true
            gameView.hidden   = true
            
            // Captures time to display on winner screen
            if Double(time) > 0 {
                // Inserts the user's time into the final time label.
                finalTime.text = "Your final time:\n\t \(time)!!"
            }
        }
        // Whether or not the user won, we still have to renable user interaction after two boxes have been matched.
        view.userInteractionEnabled = true
    }
    
    // Action set to start game with timer and hide stating screen
    @IBAction func playButton(sender: UIButton) {
        playScreenView.hidden = true
        headerView.hidden = false
        gameView.hidden  = false
        finalBackgroundView.hidden = true
        
        showCardImages(playButton)
        startGameTime()
    }
    
    // Resets game, leaves final game result screen and begins at Play screen
    @IBAction func resetGame(sender: UIButton) {
        playScreenView.hidden = false
        headerView.hidden = true
        gameView.hidden  = true
        finalBackgroundView.hidden = true
    }
    
    // MARK: - Time counter and delay start for image review
    
    // Function shows the card images for 5 seconds then flips over
    func showCardImages(sender: UIButton) {
        UIView.transitionWithView(sender, duration: 5.0, options: .TransitionFlipFromRight, animations: {
            sender.setImage(self.image, forState: .Normal)
            }, completion: nil)
    }
    
    // Current time and date
    let userCalendar = NSCalendar.currentCalendar()
    
    
    // Update the text from the label
    func gameCounter() -> String {
        // Use extension TimeIntervals to create time of min and sec
        seconds += 1.0
        time = seconds.timeString
        timerDisplay.text = time
        
        return time
    }
    
    // Starts time when play button is pressed
    func startGameTime() {
        
        self.timer.invalidate()
        self.timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(ViewController.gameCounter), userInfo: nil, repeats: true)
    }
}
