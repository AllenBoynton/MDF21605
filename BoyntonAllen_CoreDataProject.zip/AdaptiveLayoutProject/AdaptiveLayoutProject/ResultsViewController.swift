//
//  ResultsViewController.swift
//  AdaptiveLayoutProject
//
//  Created by Allen Boynton on 5/26/16.
//  Copyright © 2016 Full Sail. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {
    
    // Outlets for high score results
    
    @IBOutlet var timeRanks: [UILabel]!
    
    @IBOutlet var nameRanks: [UILabel]!
    
    @IBOutlet var movesRanks: [UILabel]!

    @IBOutlet var dateRanks: [UILabel]!
    
    @IBOutlet var headingLabels: [UILabel]!
    
    @IBOutlet weak var playersRanking: UILabel!
    
    var allArrays = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Minimize code by using array of arrays
        
        allArrays = [timeRanks!, nameRanks!, movesRanks!, dateRanks!, headingLabels!]
        
        // Label attributes
        
        for all in allArrays {
            all.layer.borderWidth = 2
            all.layer.borderColor = UIColor.blackColor().CGColor
        }
        
        for timeRank in timeRanks {
            timeRank.layer.borderWidth = 2
            timeRank.layer.borderColor = UIColor.blackColor().CGColor
        }

        for names in nameRanks {
            names.layer.borderWidth = 2
            names.layer.borderColor = UIColor.blackColor().CGColor
        }

        for moves in movesRanks {
            moves.layer.borderWidth = 2
            moves.layer.borderColor = UIColor.blackColor().CGColor
        }

        for date in dateRanks {
            date.layer.borderWidth = 2
            date.layer.borderColor = UIColor.blackColor().CGColor
        }

        for heading in headingLabels {
            heading.layer.borderWidth = 2
            heading.layer.borderColor = UIColor.blackColor().CGColor
        }

    }

    @IBAction func resetGameButton(sender: UIButton) {
        
        // return to home
        dismissViewControllerAnimated(true, completion: nil)
    }
}
