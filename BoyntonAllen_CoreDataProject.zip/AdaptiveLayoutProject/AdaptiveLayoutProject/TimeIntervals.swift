//
//  TimeIntervals.swift
//  AdaptiveLayoutProject
//
//  Created by Allen Boynton on 5/6/16.
//  Copyright © 2016 Full Sail. All rights reserved.
//

import Foundation
import UIKit

extension NSTimeInterval {
    var timeString: String {
        return String(format:"%d:%02d", minutes, seconds)
    }
    var minutes: Int {
        return Int(self/60.0 % 60)
    }
    var seconds: Int {
        return Int(self % 60)
    }
}
